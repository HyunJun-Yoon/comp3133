import express from 'express';
import mongoose from 'mongoose';
import { ApolloServer, gql } from 'apollo-server-express';
import { resolvers } from './resolver';
import { typeDefs } from './typeDefs';

const server = async () => {
  const app = express();
  const server = new ApolloServer({
    typeDefs,
    resolvers
  });

  server.applyMiddleware({ app });

  try {
    await mongoose.connect(
      'mongodb+srv://hyunjun:wjstjf1443@cluster0.7abhc.mongodb.net/gbc_full_stack?retryWrites=true&w=majority'
    );
  } catch (error) {
    console.log(error);
  }

  app.get('/', (req, res) => res.send('Hello world'));

  app.listen({ port: 4001 }, () => {
    console.log('connected');
  });
};

server();
